package com.example.appppppp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
